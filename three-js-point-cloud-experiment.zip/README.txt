A Pen created at CodePen.io. You can find this one at http://codepen.io/seanseansean/pen/EaBZEY.

 Working on a larger -personal- project involving a similar animation.  Still tooling with it.  